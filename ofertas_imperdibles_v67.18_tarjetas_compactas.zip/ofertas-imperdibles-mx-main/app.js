:root {
  --fondo: #f5f7f8;
  --blanco: #ffffff;
  --texto: #17211b;
  --gris: #66736c;
  --borde: #e0e7e4;
  --turquesa: #0f9f92;
  --turquesa-oscuro: #08786f;
  --turquesa-claro: #e8f7f4;
  --whatsapp: #25d366;
  --error: #a12626;
}

* {
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
}

body {
  margin: 0;
  padding-bottom: 82px;
  font-family: Arial, Helvetica, sans-serif;
  color: var(--texto);
  background:
    radial-gradient(circle at top left, rgba(52, 135, 233, 0.05), transparent 27%),
    radial-gradient(circle at top right, rgba(139, 92, 230, 0.04), transparent 30%),
    var(--fondo);
}

button,
a {
  -webkit-tap-highlight-color: transparent;
}

.encabezado {
  position: relative;
  overflow:hidden;
  padding:7px 14px 12px;
}

.logo {
  display: block;
  width: min(330px, 82vw);
  height: auto;
  margin: 0 auto 9px;
}

.whatsapp-cabecera {
  display: inline-flex;
  align-items: center;
  gap: 9px;
  padding: 7px 12px;
  margin-bottom: 9px;
  border: 1px solid rgba(37, 211, 102, 0.25);
  border-radius: 999px;
  color: #176a39;
  background: #f1fff6;
  text-decoration: none;
}

.whatsapp-cabecera strong,
.whatsapp-cabecera small {
  display: block;
  text-align: left;
}

.whatsapp-cabecera strong {
  font-size: 13px;
}

.whatsapp-cabecera small {
  color: #52755e;
  font-size: 11px;
}

.whatsapp-icono {
  width: 31px;
  height: 31px;
  display: grid;
  place-items: center;
  border-radius: 50%;
  color: white;
  background: var(--whatsapp);
}

.encabezado > p {
  margin: 0;
  color: var(--gris);
  font-size: 14px;
}

.contenedor {
  width: min(1120px, calc(100% - 28px));
  margin: 20px auto 42px;
}

.instruccion-cupones {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 19px;
  padding: 12px 14px;
  border: 1px solid #bfd8f3;
  border-radius: 13px;
  color: #344b63;
  background: #eef6ff;
  font-size: 13px;
  line-height: 1.45;
}

.instruccion-cupones p {
  margin: 0;
}

.titulo-fila {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 11px;
}

.titulo-con-separador {
  position: relative;
  padding-bottom: 11px;
}

.titulo-con-separador::after {
  content: "";
  position: absolute;
  inset: auto 0 0;
  border-bottom: 1px dashed #b9c9c3;
}

.titulo-seccion {
  margin: 0;
  font-size: 24px;
}

.actualizacion {
  display: flex;
  align-items: center;
  gap: 8px;
  color: var(--gris);
  font-size: 12px;
}

.boton-recargar {
  padding: 8px 11px;
  border: 1px solid var(--borde);
  border-radius: 9px;
  color: #267261;
  background: white;
  font-weight: 700;
  cursor: pointer;
}

.estado-carga {
  margin: 0 0 13px;
  color: var(--gris);
  font-size: 13px;
}

.estado-carga.error {
  color: var(--error);
  font-weight: 700;
}

.popular-wrapper {
  margin-bottom: 19px;
}

.popular-titulo {
  margin-bottom: 11px;
}

.popular-titulo h2 {
  margin: 0 0 3px;
  font-size: 21px;
}

.popular-titulo p {
  margin: 0;
  color: var(--gris);
  font-size: 13px;
}

.subtitulo-lista {
  margin: 0 0 12px;
  font-size: 19px;
}

.cupones-lista {
  display: grid;
  gap: 12px;
}

.cupon {
  --tono-1: #0f9f92;
  --tono-2: #08786f;
  --tono-suave: #e8f7f4;

  display: grid;
  grid-template-columns: minmax(190px, 28%) 1fr;
  overflow: hidden;
  min-height: 138px;
  border: 1px solid color-mix(in srgb, var(--tono-1) 22%, white);
  border-radius: 18px;
  background: white;
  box-shadow: 0 7px 20px rgba(27, 44, 38, 0.07);
  animation: aparecer-cupon 0.24s ease-out;
}

@keyframes aparecer-cupon {
  from {
    opacity: 0;
    transform: translateY(6px);
  }

  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.cupon[data-color="azul"] {
  --tono-1: #3487e9;
  --tono-2: #2464c3;
  --tono-suave: #edf5ff;
}

.cupon[data-color="morado"] {
  --tono-1: #8b5ce6;
  --tono-2: #6840be;
  --tono-suave: #f4efff;
}

.cupon[data-color="coral"] {
  --tono-1: #f47763;
  --tono-2: #ce5745;
  --tono-suave: #fff0ed;
}

.cupon[data-color="oliva"] {
  --tono-1: #78945f;
  --tono-2: #56723f;
  --tono-suave: #eff5eb;
}

.cupon.popular {
  --tono-1: #e4ad27;
  --tono-2: #b17c08;
  --tono-suave: #fff7df;
  border-color: rgba(196, 145, 22, 0.28);
}

.cupon-encabezado {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 18px 20px;
  overflow: hidden;
  color: white;
  background: linear-gradient(135deg, var(--tono-2), var(--tono-1));
}

.cupon-encabezado::after {
  content: "";
  position: absolute;
  width: 145px;
  height: 145px;
  top: -65px;
  right: -48px;
  border-radius: 45%;
  background: rgba(255, 255, 255, 0.1);
  transform: rotate(22deg);
}

.etiqueta-popular,
.descuento,
.subtitulo {
  position: relative;
  z-index: 1;
}

.etiqueta-popular {
  align-self: flex-start;
  margin-bottom: 7px;
  padding: 4px 8px;
  border-radius: 7px;
  background: rgba(255, 255, 255, 0.2);
  font-size: 10px;
  font-weight: 800;
}

.descuento {
  margin: 0;
  font-size: 29px;
}

.subtitulo {
  margin: 3px 0 0;
  font-size: 12px;
  font-weight: 700;
}

.cupon-contenido {
  display: grid;
  grid-template-columns: 1fr minmax(195px, 31%);
  align-items: center;
  gap: 15px;
  padding: 15px 17px;
}

.datos-cupon {
  display: grid;
  grid-template-columns: repeat(2, minmax(120px, 1fr));
  gap: 9px;
}

.dato {
  margin: 0;
  padding: 10px 11px;
  border-radius: 10px;
  color: #34413b;
  background: var(--tono-suave);
  font-size: 13px;
  font-weight: 700;
}

.acciones-cupon {
  display: grid;
  grid-template-columns: 1fr 45px;
  gap: 7px;
}

.boton-canjear,
.boton-compartir {
  border-radius: 11px;
  font-weight: 800;
  cursor: pointer;
}

.boton-canjear {
  padding: 12px 9px;
  border: 1px solid var(--tono-2);
  color: white;
  background: linear-gradient(135deg, var(--tono-2), var(--tono-1));
  font-size: 14px;
}

.boton-compartir {
  display: grid;
  place-items: center;
  padding: 10px;
  border: 1px solid color-mix(in srgb, var(--tono-1) 55%, white);
  color: var(--tono-2);
  background: white;
}

.boton-compartir svg {
  width: 20px;
  height: 20px;
  fill: currentColor;
}

.boton-canjear:disabled {
  opacity: 0.85;
  cursor: wait;
}

.mensaje {
  min-height: 16px;
  margin: 6px 0 0;
  text-align: center;
  color: var(--tono-2);
  font-size: 11px;
  font-weight: 700;
}

.contador {
  margin: 2px 0 0;
  text-align: center;
  color: var(--gris);
  font-size: 11px;
}

.sin-cupones {
  padding: 32px 18px;
  text-align: center;
  border: 1px solid var(--borde);
  border-radius: 17px;
  background: white;
}

.sin-cupones-icono {
  width: 58px;
  height: 58px;
  display: grid;
  place-items: center;
  margin: 0 auto 13px;
  border-radius: 50%;
  background: #f0f4f8;
  font-size: 27px;
  filter: grayscale(1);
  opacity: 0.65;
}

.sin-cupones h2 {
  margin: 0 0 7px;
  font-size: 21px;
}

.sin-cupones p {
  margin: 0 0 5px;
  color: var(--gris);
}

.aviso-inferior {
  position: relative;
  margin-top: 24px;
  padding-top: 20px;
}

.aviso-inferior::before {
  content: "";
  position: absolute;
  inset: 0 0 auto;
  border-top: 2px dashed #bcc9c4;
}

.aviso-inferior p {
  margin: 0;
  padding: 12px 15px;
  border: 1px solid #ecd96a;
  border-radius: 13px;
  background: #fff9d7;
  color: #4f554f;
  text-align: center;
  font-size: 13px;
  line-height: 1.45;
}

/* Publicidad rotativa */
.publicidad-wrapper {
  margin-top: 14px;
}

.publicidad-cabecera {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 7px;
  padding: 0 7px;
  color: #8a9992;
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.7px;
}

.publicidad-indicadores {
  display: flex;
  gap: 5px;
}

.publicidad-punto {
  width: 7px;
  height: 7px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: #ccd6d2;
  cursor: pointer;
}

.publicidad-punto.activo {
  width: 18px;
  border-radius: 99px;
  background: var(--turquesa);
}

.publicidad-carrusel {
  position: relative;
  overflow: hidden;
  border: 1px solid #d8e5dd;
  border-radius: 18px;
  background: linear-gradient(115deg, #ffffff, #f8fffa);
  box-shadow: 0 7px 20px rgba(7, 149, 42, 0.06);
  touch-action: pan-y;
}

.publicidad-contenido {
  display: grid;
  grid-template-columns: minmax(110px, 155px) 1fr;
  align-items: center;
  gap: 18px;
  min-height: 150px;
  padding: 15px 62px;
  animation: publicidad-fade 0.3s ease;
}

@keyframes publicidad-fade {
  from {
    opacity: 0.25;
    transform: translateX(8px);
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}

.publicidad-contenido img {
  display: block;
  width: 100%;
  height: 120px;
  object-fit: contain;
  border-radius: 12px;
  background: white;
}

.publicidad-copy h2 {
  margin: 0 0 5px;
  font-size: 23px;
}

.publicidad-copy p {
  margin: 0 0 12px;
  max-width: 700px;
  color: #4d5d54;
  line-height: 1.45;
  font-size: 14px;
}

.publicidad-boton {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 10px 14px;
  border-radius: 10px;
  color: white;
  background: linear-gradient(135deg, #067420, #07952a);
  font-size: 13px;
  font-weight: 800;
  text-decoration: none;
}

.publicidad-flecha {
  position: absolute;
  top: 50%;
  z-index: 2;
  width: 38px;
  height: 48px;
  border: 0;
  border-radius: 11px;
  color: #276441;
  background: rgba(255, 255, 255, 0.9);
  box-shadow: 0 4px 12px rgba(30, 60, 45, 0.13);
  font-size: 30px;
  cursor: pointer;
  transform: translateY(-50%);
}

.publicidad-flecha-anterior {
  left: 12px;
}

.publicidad-flecha-siguiente {
  right: 12px;
}

/* Navegación inferior */
.navegacion-inferior {
  position: fixed;
  left: 50%;
  bottom: 10px;
  z-index: 9000;
  width: min(460px, calc(100% - 20px));
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 7px;
  padding: 7px;
  border: 1px solid rgba(23, 33, 27, 0.12);
  border-radius: 18px;
  background: rgba(255, 255, 255, 0.96);
  box-shadow: 0 12px 35px rgba(24, 45, 37, 0.18);
  backdrop-filter: blur(12px);
  transform: translateX(-50%);
}

.tab-inferior {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  min-height: 48px;
  border: 0;
  border-radius: 13px;
  color: #66736c;
  background: transparent;
  font-size: 14px;
  cursor: pointer;
}

.tab-inferior span {
  font-size: 19px;
}

.tab-inferior.activo {
  color: white;
  background: linear-gradient(135deg, #08786f, #0f9f92);
  box-shadow: 0 5px 14px rgba(15, 159, 146, 0.24);
}

.tab-inferior.activo::after {
  content: "";
  position: absolute;
  left: 30%;
  right: 30%;
  bottom: 5px;
  height: 3px;
  border-radius: 99px;
  background: rgba(255, 255, 255, 0.9);
}

/* Modal */
.modal-redireccion[hidden] {
  display: none;
}

.modal-redireccion {
  position: fixed;
  inset: 0;
  z-index: 9999;
  display: grid;
  place-items: center;
  padding: 20px;
  background: rgba(11, 27, 22, 0.68);
  backdrop-filter: blur(3px);
}

.modal-contenido {
  width: min(430px, 100%);
  padding: 26px 21px 23px;
  border-radius: 20px;
  background: white;
  text-align: center;
  box-shadow: 0 22px 60px rgba(0, 0, 0, 0.26);
}

.modal-icono {
  margin-bottom: 8px;
  font-size: 41px;
}

.modal-contenido h2 {
  margin: 0 0 9px;
  color: #08786f;
}

.modal-contenido p {
  margin: 0;
  color: #47565e;
  line-height: 1.5;
}

.cronometro {
  width: 80px;
  height: 80px;
  display: grid;
  place-items: center;
  margin: 18px auto 14px;
  border: 6px solid #e2f5f1;
  border-top-color: #0f9f92;
  border-radius: 50%;
}

.cronometro span {
  color: #08786f;
  font-size: 33px;
  font-weight: 900;
}

.modal-codigo {
  padding: 9px 11px;
  border-radius: 9px;
  color: #08786f !important;
  background: #e2f5f1;
}

footer {
  padding: 0 18px 27px;
  color: var(--gris);
  text-align: center;
  font-size: 12px;
}

@media (max-width: 760px) {
  .titulo-fila {
    align-items: flex-start;
    flex-direction: column;
  }

  .actualizacion {
    width: 100%;
    justify-content: space-between;
  }

  .cupon {
    grid-template-columns: 1fr;
  }

  .cupon-encabezado {
    min-height: 108px;
  }

  .cupon-contenido {
    grid-template-columns: 1fr;
    gap: 11px;
  }

  .publicidad-contenido {
    grid-template-columns: 95px 1fr;
    gap: 12px;
    min-height: 135px;
    padding: 14px 48px;
  }

  .publicidad-contenido img {
    height: 95px;
  }

  .publicidad-copy h2 {
    font-size: 19px;
  }

  .publicidad-copy p {
    display: -webkit-box;
    overflow: hidden;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    margin-bottom: 9px;
    font-size: 12px;
  }

  .publicidad-flecha {
    width: 31px;
    height: 43px;
  }

  .publicidad-flecha-anterior {
    left: 7px;
  }

  .publicidad-flecha-siguiente {
    right: 7px;
  }
}

@media (max-width: 430px) {
  .logo {
    width: min(290px, 88vw);
  }

  .titulo-seccion {
    font-size: 21px;
  }

  .datos-cupon {
    grid-template-columns: 1fr;
  }

  .publicidad-contenido {
    grid-template-columns: 78px 1fr;
    padding: 12px 39px;
  }

  .publicidad-contenido img {
    height: 82px;
  }

  .publicidad-copy h2 {
    font-size: 17px;
  }

  .publicidad-boton {
    padding: 8px 10px;
    font-size: 11px;
  }
}


/* Precios de publicidad */
.publicidad-precios {
  display: flex;
  align-items: stretch;
  flex-wrap: wrap;
  gap: 8px;
  margin: 0 0 10px;
}

.precio-publicado-bloque,
.precio-cupon-bloque {
  min-width: 128px;
  padding: 8px 10px;
  border-radius: 10px;
}

.precio-publicado-bloque {
  border: 1px solid #e0e7e4;
  background: #f6f8f7;
}

.precio-cupon-bloque {
  border: 1px solid #bce2c5;
  background: #edf9f0;
}

.precio-publicado-bloque span,
.precio-cupon-bloque span {
  display: block;
  margin-bottom: 2px;
  color: #68756f;
  font-size: 10px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.35px;
}

.precio-publicado-bloque strong {
  color: #59645f;
  font-size: 16px;
  text-decoration: line-through;
  text-decoration-thickness: 1px;
}

.precio-cupon-bloque strong {
  color: #067420;
  font-size: 19px;
}

.publicidad-aviso-cupon {
  margin: 0 0 9px !important;
  color: #42624c !important;
  font-size: 11px !important;
  line-height: 1.35 !important;
}

.modal-cupon-oculto {
  margin-top: 12px !important;
  padding: 9px 11px;
  border-radius: 9px;
  color: #08786f !important;
  background: #e2f5f1;
  font-size: 13px;
  font-weight: 700;
}

@media (max-width: 430px) {
  .publicidad-precios {
    gap: 6px;
    margin-bottom: 8px;
  }

  .precio-publicado-bloque,
  .precio-cupon-bloque {
    min-width: 105px;
    padding: 7px 8px;
  }

  .precio-publicado-bloque strong {
    font-size: 14px;
  }

  .precio-cupon-bloque strong {
    font-size: 17px;
  }

  .publicidad-aviso-cupon {
    font-size: 10px !important;
  }
}


/* V60.6 — Aviso inferior eliminado */
.aviso-inferior {
  display: none !important;
}

.publicidad-wrapper {
  margin-top: 16px !important;
  padding-top: 14px;
  border-top: 1px dashed #cbd5d0;
}


/* Acciones y secciones de ofertas V61 */
.seccion-ofertas-categoria { scroll-margin-top: 18px; }
.publicidad-acciones { display: flex; align-items: stretch; gap: 8px; flex-wrap: wrap; }
.publicidad-compartir {
  display: inline-flex; align-items: center; justify-content: center;
  padding: 10px 14px; border: 1px solid #b9d4c4; border-radius: 10px;
  color: #17633b; background: #fff; font-size: 13px; font-weight: 800; cursor: pointer;
}
.publicidad-compartir:hover { background: #edf8f1; }
.publicidad-mensaje { min-height: 16px; margin: 6px 0 0 !important; color: #17633b !important; font-size: 11px !important; font-weight: 700; }
@media (max-width: 430px) {
  .publicidad-acciones { gap: 6px; }
  .publicidad-compartir { padding: 8px 10px; font-size: 11px; }
}


/* V61.1 — Módulos de productos con estructura similar a cupones */
.modulo-ofertas-categoria {
  margin-top: 18px;
  scroll-margin-top: 18px;
}

.ofertas-grid-compacta {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.tarjeta-oferta {
  overflow: hidden;
  border: 1px solid #d8e1dc;
  border-radius: 15px;
  background: #fff;
  box-shadow: 0 4px 14px rgba(20, 45, 32, 0.07);
}

.oferta-imagen-contenedor {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  aspect-ratio: 16 / 10;
  padding: 8px;
  background: #f7f9f8;
}

.oferta-imagen-contenedor.sin-imagen::after {
  content: "Imagen no disponible";
  color: #7a8780;
  font-size: 12px;
  font-weight: 700;
}

.oferta-imagen {
  width: 100%;
  height: 100%;
  object-fit: contain;
  border-radius: 10px;
}

.oferta-contenido {
  padding: 11px;
}

.oferta-contenido h3 {
  margin: 0;
  color: #202a25;
  font-size: 15px;
  line-height: 1.25;
}

.oferta-descripcion {
  display: -webkit-box;
  overflow: hidden;
  margin: 6px 0 0;
  color: #5d6963;
  font-size: 12px;
  line-height: 1.35;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.oferta-precios {
  display: grid;
  gap: 6px;
  margin-top: 10px;
}

.oferta-precios.con-cupon {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.oferta-precios > div {
  min-width: 0;
  padding: 7px 8px;
  border-radius: 9px;
  background: #f1f5f3;
}

.oferta-precios span {
  display: block;
  color: #65716b;
  font-size: 9px;
  font-weight: 700;
}

.oferta-precios strong {
  display: block;
  margin-top: 2px;
  color: #25312b;
  font-size: 14px;
  line-height: 1.15;
}

.oferta-precios .precio-destacado {
  background: #eaf7ef;
}

.oferta-precios .precio-destacado strong {
  color: #14703f;
}

.oferta-cupon {
  margin: 8px 0 0;
  color: #3c4842;
  font-size: 11px;
}

.oferta-acciones {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 7px;
  margin-top: 10px;
}

.oferta-ver,
.oferta-compartir {
  min-height: 39px;
  border-radius: 9px;
  font-size: 11px;
  font-weight: 800;
  cursor: pointer;
}

.oferta-ver {
  border: 0;
  color: #fff;
  background: #16864c;
}

.oferta-compartir {
  padding: 0 10px;
  border: 1px solid #b9d4c4;
  color: #17633b;
  background: #fff;
}

.oferta-ver:hover { background: #11713f; }
.oferta-compartir:hover { background: #edf8f1; }

.oferta-mensaje {
  min-height: 14px;
  margin: 5px 0 0;
  color: #17633b;
  font-size: 10px;
  font-weight: 700;
}

@media (max-width: 620px) {
  .ofertas-grid-compacta {
    grid-template-columns: 1fr;
    gap: 10px;
  }

  .tarjeta-oferta {
    display: grid;
    grid-template-columns: 112px minmax(0, 1fr);
  }

  .oferta-imagen-contenedor {
    height: 100%;
    min-height: 156px;
    aspect-ratio: auto;
    border-radius: 0;
  }

  .oferta-contenido {
    min-width: 0;
    padding: 10px;
  }

  .oferta-contenido h3 { font-size: 14px; }
  .oferta-descripcion { font-size: 11px; }
  .oferta-precios strong { font-size: 13px; }
  .oferta-acciones { grid-template-columns: minmax(0, 1fr) 39px; }
  .oferta-compartir { overflow: hidden; width: 39px; padding: 0; font-size: 0; }
  .oferta-compartir::before { content: "↗"; font-size: 18px; }
}

/* V61.2 — vistas exclusivas de cupones y productos */
.vista-principal[hidden] { display: none !important; }

.sin-ofertas-categoria {
  grid-column: 1 / -1;
  padding: 32px 18px;
  border: 1px dashed #cdd9d2;
  border-radius: 14px;
  text-align: center;
  background: #fff;
}
.sin-ofertas-categoria div { font-size: 30px; }
.sin-ofertas-categoria h3 { margin: 8px 0 4px; color: #25342c; font-size: 16px; }
.sin-ofertas-categoria p { margin: 0; color: #6b7770; font-size: 13px; }


/* V61.3 — control robusto de vistas principales */
[hidden] { display: none !important; }
.vista-principal.vista-oculta { display: none !important; }
.vista-principal.vista-activa { display: block; }
#vista-cupones.vista-activa,
#seccion-comunidad-anirona.vista-activa,
#seccion-ofertas-amazon.vista-activa,
#seccion-ofertas-mercado-libre.vista-activa {
  margin-top: 0;
}


/* V61.4 — contador de visitas en ofertas */
.oferta-meta {
  display: flex;
  align-items: center;
  min-height: 20px;
  margin-top: 7px;
}
.oferta-visitas {
  color: #77827c;
  font-size: 10.5px;
  font-weight: 400;
}


/* V61.5 — Logos, compartir uniforme y acciones */
.titulo-seccion-con-logo {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.titulo-seccion-con-logo img {
  display: block;
  width: auto;
  height: 22px;
  max-width: 54px;
  object-fit: contain;
}

.publicidad-acciones {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 45px;
  align-items: stretch;
  gap: 7px;
}

.publicidad-acciones .publicidad-boton {
  min-width: 0;
}

.publicidad-acciones .publicidad-compartir,
.oferta-acciones .oferta-compartir {
  width: 45px;
  min-width: 45px;
  min-height: 39px;
  padding: 9px;
  border-radius: 11px;
  font-size: 0;
  font-weight: 400;
}

.publicidad-acciones .publicidad-compartir svg,
.oferta-acciones .oferta-compartir svg {
  width: 20px;
  height: 20px;
  fill: currentColor;
}

.oferta-acciones {
  grid-template-columns: minmax(0, 1fr) 45px;
}

@media (max-width: 430px) {
  .titulo-seccion-con-logo img {
    height: 19px;
    max-width: 47px;
  }

  .publicidad-acciones {
    grid-template-columns: minmax(0, 1fr) 42px;
  }

  .publicidad-acciones .publicidad-compartir,
  .oferta-acciones .oferta-compartir {
    width: 42px;
    min-width: 42px;
  }

  .oferta-acciones {
    grid-template-columns: minmax(0, 1fr) 42px;
  }
}


/* V61.6 — Ajustes de acciones y encabezado */
.publicidad-cabecera > span {
  font-weight: 400;
}

.publicidad-acciones {
  grid-template-columns: minmax(210px, 1fr) 40px;
  gap: 5px;
}

.publicidad-acciones .publicidad-boton {
  white-space: nowrap;
  padding-left: 12px;
  padding-right: 12px;
  font-size: clamp(11px, 2.9vw, 13px);
}

.publicidad-acciones .publicidad-compartir {
  width: 40px;
  min-width: 40px;
  padding: 8px;
}

.oferta-acciones .oferta-compartir {
  /* Misma apariencia que el botón de OFERTAS DEL DÍA */
  width: 40px;
  min-width: 40px;
  padding: 8px;
  border-radius: 11px;
}

@media (max-width: 430px) {
  .publicidad-acciones {
    grid-template-columns: minmax(0, 1fr) 38px;
    gap: 4px;
  }

  .publicidad-acciones .publicidad-compartir,
  .oferta-acciones .oferta-compartir {
    width: 38px;
    min-width: 38px;
    padding: 7px;
  }

  .publicidad-acciones .publicidad-boton {
    padding-left: 8px;
    padding-right: 8px;
    font-size: 11px;
    letter-spacing: -0.01em;
  }
}


/* V61.8 — Compartir unificado en todas las ofertas */
.oferta-compartir::before {
  content: none !important;
  display: none !important;
}

.oferta-compartir svg,
.publicidad-compartir svg {
  display: block;
  width: 20px;
  height: 20px;
  fill: currentColor;
}

.oferta-compartir,
.publicidad-compartir {
  align-items: center;
  justify-content: center;
}


/* V62.1 — Tarjetas compactas, dos por fila */
.ofertas-grid-compacta {
  grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
  gap: 9px;
}

.tarjeta-oferta {
  display: flex !important;
  flex-direction: column;
  min-width: 0;
  border-radius: 13px;
  box-shadow: 0 3px 11px rgba(20, 45, 32, 0.06);
}

.oferta-imagen-contenedor {
  width: 100%;
  height: auto !important;
  min-height: 0 !important;
  aspect-ratio: 1 / 0.72 !important;
  padding: 6px;
}

.oferta-imagen {
  border-radius: 8px;
}

.oferta-contenido {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-width: 0;
  padding: 8px;
}

.oferta-contenido h3 {
  display: -webkit-box;
  overflow: hidden;
  min-height: 30px;
  font-size: 12.5px;
  line-height: 1.2;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
}

.oferta-descripcion {
  margin-top: 4px;
  font-size: 10px;
  line-height: 1.25;
  -webkit-line-clamp: 2;
}

.oferta-precios {
  gap: 4px;
  margin-top: 7px;
}

.oferta-precios.con-cupon {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

.oferta-precios > div {
  padding: 5px 6px;
  border-radius: 8px;
}

.oferta-precios span {
  font-size: 7.5px;
  line-height: 1.15;
}

.oferta-precios strong {
  margin-top: 1px;
  font-size: 11.5px;
}

.oferta-cupon {
  margin-top: 6px;
  font-size: 8.8px;
  line-height: 1.25;
}

.oferta-meta {
  margin-top: 6px;
}

.oferta-visitas {
  font-size: 9px;
}

.oferta-acciones {
  grid-template-columns: minmax(0, 1fr) 34px !important;
  gap: 5px;
  margin-top: auto;
  padding-top: 7px;
}

.oferta-ver,
.oferta-compartir {
  min-height: 34px;
  border-radius: 9px;
}

.oferta-ver {
  padding: 5px 6px;
  font-size: 9.2px;
  line-height: 1.1;
  font-weight: 700;
}

.oferta-acciones .oferta-compartir {
  display: inline-flex;
  width: 34px !important;
  min-width: 34px !important;
  padding: 7px !important;
  border-radius: 9px;
  font-size: 0;
}

.oferta-acciones .oferta-compartir::before {
  content: none !important;
  display: none !important;
}

.oferta-acciones .oferta-compartir svg {
  display: block;
  width: 18px;
  height: 18px;
  fill: currentColor;
}

.oferta-mensaje {
  min-height: 10px;
  margin-top: 3px;
  font-size: 8px;
}

@media (max-width: 620px) {
  .ofertas-grid-compacta {
    grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
    gap: 7px;
  }

  .tarjeta-oferta {
    display: flex !important;
    grid-template-columns: none !important;
  }

  .oferta-imagen-contenedor {
    height: auto !important;
    min-height: 0 !important;
    aspect-ratio: 1 / 0.75 !important;
  }

  .oferta-contenido {
    padding: 7px;
  }

  .oferta-contenido h3 {
    min-height: 28px;
    font-size: 11.5px;
  }

  .oferta-descripcion {
    font-size: 9px;
  }

  .oferta-precios strong {
    font-size: 10.5px;
  }

  .oferta-cupon {
    font-size: 8px;
  }

  .oferta-acciones {
    grid-template-columns: minmax(0, 1fr) 32px !important;
    gap: 4px;
  }

  .oferta-ver {
    min-height: 32px;
    padding: 4px;
    font-size: 8.5px;
  }

  .oferta-acciones .oferta-compartir {
    width: 32px !important;
    min-width: 32px !important;
    min-height: 32px;
    padding: 6px !important;
  }

  .oferta-acciones .oferta-compartir svg {
    width: 17px;
    height: 17px;
  }
}

@media (max-width: 360px) {
  .ofertas-grid-compacta {
    gap: 6px;
  }

  .oferta-contenido {
    padding: 6px;
  }

  .oferta-contenido h3 {
    font-size: 10.8px;
  }

  .oferta-descripcion {
    -webkit-line-clamp: 1;
  }

  .oferta-precios > div {
    padding: 4px;
  }

  .oferta-precios span {
    font-size: 7px;
  }

  .oferta-precios strong {
    font-size: 9.8px;
  }

  .oferta-ver {
    font-size: 8px;
  }
}


/* V62.2 — Se elimina el aviso superior y se mejora la navegación de secciones */
#vista-cupones > .titulo-fila:first-child {
  margin-top: 0;
}

.menu-ofertas-contenedor {
  position: relative;
  width: min(930px, 100%);
  margin: 9px auto 0;
  padding: 0 34px 18px;
}

.menu-ofertas-contenedor::before,
.menu-ofertas-contenedor::after {
  content: "";
  position: absolute;
  z-index: 2;
  top: 0;
  bottom: 18px;
  width: 28px;
  pointer-events: none;
  opacity: 0;
  transition: opacity .18s ease;
}

.menu-ofertas-contenedor::before {
  left: 31px;
  background: linear-gradient(90deg, rgba(255,255,255,.96), rgba(255,255,255,0));
}

.menu-ofertas-contenedor::after {
  right: 31px;
  background: linear-gradient(270deg, rgba(255,255,255,.96), rgba(255,255,255,0));
}

.menu-ofertas-contenedor:has(.menu-ofertas.puede-desplazar-izquierda)::before {
  opacity: 1;
}

.menu-ofertas-contenedor:has(.menu-ofertas.puede-desplazar-derecha)::after {
  opacity: 1;
}

.menu-ofertas {
  width: 100% !important;
  margin: 0 !important;
  padding: 3px 5px 5px !important;
  overflow-x: auto;
  overscroll-behavior-x: contain;
  scroll-snap-type: x proximity;
  scroll-behavior: smooth;
  -webkit-overflow-scrolling: touch;
}

.menu-ofertas button {
  scroll-snap-align: center;
}

.menu-ofertas-flecha {
  position: absolute;
  z-index: 4;
  top: 4px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 29px;
  height: 34px;
  padding: 0;
  border: 1px solid rgba(21, 147, 106, .20);
  border-radius: 10px;
  color: #176d57;
  background: rgba(255, 255, 255, .96);
  box-shadow: 0 4px 13px rgba(29, 63, 49, .10);
  font-size: 23px;
  font-weight: 300;
  line-height: 1;
  cursor: pointer;
  transition:
    transform .16s ease,
    border-color .16s ease,
    box-shadow .16s ease;
}

.menu-ofertas-flecha:hover,
.menu-ofertas-flecha:focus-visible {
  transform: translateY(-1px);
  border-color: rgba(21, 147, 106, .42);
  box-shadow: 0 7px 16px rgba(29, 63, 49, .14);
  outline: none;
}

.menu-ofertas-flecha:active {
  transform: scale(.96);
}

.menu-ofertas-flecha-anterior {
  left: 1px;
}

.menu-ofertas-flecha-siguiente {
  right: 1px;
}

.menu-ofertas-flecha[hidden],
.menu-ofertas-indicador[hidden] {
  display: none !important;
}

.menu-ofertas-indicador {
  position: absolute;
  left: 50%;
  bottom: 1px;
  transform: translateX(-50%);
  color: #718078;
  font-size: 9.5px;
  font-weight: 400;
  letter-spacing: .015em;
  white-space: nowrap;
  pointer-events: none;
  animation: menu-ofertas-pulso 1.7s ease-in-out infinite;
}

@keyframes menu-ofertas-pulso {
  0%, 100% {
    opacity: .55;
    transform: translateX(-50%);
  }
  50% {
    opacity: 1;
    transform: translateX(calc(-50% + 4px));
  }
}

@media (min-width: 850px) {
  .menu-ofertas-contenedor {
    padding-bottom: 4px;
  }

  .menu-ofertas-indicador {
    display: none;
  }
}

@media (max-width: 600px) {
  .menu-ofertas-contenedor {
    width: 100%;
    padding-right: 31px;
    padding-left: 31px;
  }

  .menu-ofertas-flecha {
    top: 3px;
    width: 27px;
    height: 33px;
    border-radius: 9px;
  }

  .menu-ofertas-contenedor::before {
    left: 28px;
  }

  .menu-ofertas-contenedor::after {
    right: 28px;
  }
}


/* V62.3 — Imágenes clicables con el mismo comportamiento del botón Ver */
button.oferta-imagen-contenedor {
  position: relative;
  display: block;
  width: 100%;
  margin: 0;
  border: 0;
  color: inherit;
  background: transparent;
  font: inherit;
  text-align: inherit;
  cursor: pointer;
  appearance: none;
  -webkit-appearance: none;
  overflow: hidden;
}

button.oferta-imagen-contenedor::before {
  content: "";
  position: absolute;
  z-index: 1;
  inset: 0;
  border: 2px solid transparent;
  border-radius: inherit;
  pointer-events: none;
  transition:
    border-color .18s ease,
    background .18s ease;
}

button.oferta-imagen-contenedor .oferta-imagen {
  transition:
    transform .22s ease,
    filter .22s ease;
}

button.oferta-imagen-contenedor:hover .oferta-imagen,
button.oferta-imagen-contenedor:focus-visible .oferta-imagen {
  transform: scale(1.035);
  filter: brightness(.98);
}

button.oferta-imagen-contenedor:hover::before {
  border-color: rgba(21, 147, 106, .20);
}

button.oferta-imagen-contenedor:focus-visible {
  outline: none;
}

button.oferta-imagen-contenedor:focus-visible::before {
  border-color: rgba(21, 147, 106, .55);
  background: rgba(21, 147, 106, .025);
}

button.oferta-imagen-contenedor:active .oferta-imagen {
  transform: scale(1.01);
}

@media (hover: none) {
  button.oferta-imagen-contenedor:hover .oferta-imagen {
    transform: none;
    filter: none;
  }
}


/* V62.5 — Tarjeta final para el canal de Comunidad Anirona */
.tarjeta-canal-anirona {
  grid-column: 1 / -1;
  display: grid !important;
  grid-template-columns: minmax(110px, 180px) minmax(0, 1fr);
  align-items: center;
  gap: 18px;
  min-height: 190px;
  padding: 20px;
  overflow: hidden;
  border: 1px solid rgba(18, 139, 75, .18);
  background:
    radial-gradient(circle at 94% 8%, rgba(73, 202, 49, .14), transparent 31%),
    linear-gradient(135deg, #ffffff 0%, #f5fbf6 100%);
  box-shadow: 0 8px 24px rgba(27, 79, 49, .08);
}

.canal-anirona-logo {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 130px;
  padding: 16px;
  border-radius: 16px;
  background: rgba(255, 255, 255, .82);
  box-shadow: inset 0 0 0 1px rgba(20, 80, 44, .07);
}

.canal-anirona-logo img {
  display: block;
  width: 100%;
  max-width: 150px;
  max-height: 72px;
  object-fit: contain;
}

.canal-anirona-contenido {
  min-width: 0;
}

.canal-anirona-etiqueta {
  display: inline-flex;
  margin-bottom: 5px;
  color: #168544;
  font-size: 9px;
  font-weight: 600;
  letter-spacing: .12em;
}

.canal-anirona-contenido h3 {
  min-height: auto;
  margin: 0;
  color: #1e3428;
  font-size: clamp(19px, 3vw, 25px);
  font-weight: 600;
  line-height: 1.1;
  -webkit-line-clamp: initial;
}

.canal-anirona-contenido > p {
  max-width: 590px;
  margin: 8px 0 0;
  color: #52635a;
  font-size: 12.5px;
  line-height: 1.45;
}

.canal-anirona-temas {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 11px;
}

.canal-anirona-temas span {
  padding: 5px 9px;
  border: 1px solid rgba(22, 133, 68, .14);
  border-radius: 999px;
  color: #42604e;
  background: rgba(255, 255, 255, .8);
  font-size: 9.5px;
  font-weight: 400;
}

.canal-anirona-boton {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 9px;
  min-height: 42px;
  margin-top: 13px;
  padding: 10px 16px;
  border: 1px solid #159447;
  border-radius: 11px;
  color: #fff;
  background: #159447;
  box-shadow: 0 6px 15px rgba(21, 148, 71, .19);
  font-size: 12px;
  font-weight: 500;
  text-decoration: none;
  transition:
    transform .16s ease,
    background .16s ease,
    box-shadow .16s ease;
}

.canal-anirona-boton svg {
  width: 20px;
  height: 20px;
  fill: currentColor;
}

.canal-anirona-boton:hover,
.canal-anirona-boton:focus-visible {
  color: #fff;
  background: #107d3b;
  box-shadow: 0 9px 20px rgba(21, 148, 71, .25);
  transform: translateY(-1px);
  outline: none;
}

.canal-anirona-boton:active {
  transform: scale(.98);
}

.canal-anirona-contenido small {
  display: block;
  margin-top: 8px;
  color: #77857d;
  font-size: 9px;
}

@media (max-width: 620px) {
  .tarjeta-canal-anirona {
    grid-template-columns: 76px minmax(0, 1fr);
    gap: 11px;
    min-height: 0;
    padding: 13px;
    border-radius: 13px;
  }

  .canal-anirona-logo {
    min-height: 88px;
    padding: 8px;
    border-radius: 12px;
  }

  .canal-anirona-logo img {
    max-width: 72px;
    max-height: 46px;
  }

  .canal-anirona-etiqueta {
    font-size: 7.5px;
  }

  .canal-anirona-contenido h3 {
    font-size: 16px;
  }

  .canal-anirona-contenido > p {
    margin-top: 5px;
    font-size: 10px;
    line-height: 1.35;
  }

  .canal-anirona-temas {
    display: none;
  }

  .canal-anirona-boton {
    min-height: 36px;
    margin-top: 9px;
    padding: 8px 10px;
    border-radius: 9px;
    font-size: 10px;
  }

  .canal-anirona-boton svg {
    width: 17px;
    height: 17px;
  }

  .canal-anirona-contenido small {
    font-size: 7.5px;
  }
}

@media (max-width: 370px) {
  .tarjeta-canal-anirona {
    grid-template-columns: 1fr;
    text-align: center;
  }

  .canal-anirona-logo {
    min-height: 66px;
  }

  .canal-anirona-contenido > p {
    margin-right: auto;
    margin-left: auto;
  }

  .canal-anirona-boton {
    width: 100%;
  }
}


/* V63.2 — Logo como enlace de inicio */
.enlace-logo-inicio {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 14px;
  text-decoration: none;
  cursor: pointer;
  transition:
    transform .18s ease,
    opacity .18s ease,
    filter .18s ease;
}

.enlace-logo-inicio:hover,
.enlace-logo-inicio:focus-visible {
  transform: scale(1.025);
  filter: brightness(1.025);
  outline: none;
}

.enlace-logo-inicio:focus-visible {
  box-shadow: 0 0 0 3px rgba(22, 133, 101, .16);
}

.enlace-logo-inicio:active {
  transform: scale(.99);
}

.enlace-logo-inicio .logo {
  display: block;
}


/* V63.3 — Logo centrado y encabezado abstracto suave */
.encabezado {
  position: relative;
  isolation: isolate;
  padding-top: 12px;
  background:
    radial-gradient(circle at 12% 10%, rgba(65, 185, 54, .12), transparent 30%),
    radial-gradient(circle at 88% 2%, rgba(18, 153, 117, .09), transparent 27%),
    linear-gradient(135deg, #ffffff 0%, #f7fcf7 54%, #f2faf5 100%) !important;
}

.encabezado::before,
.encabezado::after {
  content: "" !important;
  position: absolute;
  z-index: -1;
  display: block !important;
  border-radius: 999px;
  pointer-events: none;
  filter: blur(1px);
}

.encabezado::before {
  width: 240px;
  height: 72px;
  top: -38px;
  left: -70px;
  border: 1px solid rgba(54, 176, 64, .10);
  background: rgba(113, 208, 82, .045);
  transform: rotate(-9deg);
}

.encabezado::after {
  width: 210px;
  height: 78px;
  top: -35px;
  right: -58px;
  border: 1px solid rgba(14, 139, 111, .09);
  background: rgba(17, 158, 124, .035);
  transform: rotate(11deg);
}

.enlace-logo-inicio {
  position: relative;
  z-index: 2;
  display: flex !important;
  width: fit-content;
  max-width: 100%;
  margin: 0 auto 5px;
  align-items: center;
  justify-content: center;
  border-radius: 16px;
}

.enlace-logo-inicio .logo {
  display: block;
  width: min(315px, 78vw);
  max-height: 92px;
  margin: 0 auto !important;
  object-fit: contain;
  filter: drop-shadow(0 5px 12px rgba(30, 72, 43, .08));
}

.enlace-logo-inicio:hover,
.enlace-logo-inicio:focus-visible {
  transform: scale(1.018);
}

.barra-redes-lineal {
  position: relative;
  z-index: 2;
}

.menu-ofertas-contenedor {
  position: relative;
  z-index: 2;
}

@media (max-width: 600px) {
  .encabezado {
    padding-top: 9px;
  }

  .enlace-logo-inicio {
    margin-bottom: 3px;
  }

  .enlace-logo-inicio .logo {
    width: min(270px, 76vw);
    max-height: 78px;
  }

  .encabezado::before {
    width: 170px;
    height: 58px;
    left: -68px;
  }

  .encabezado::after {
    width: 160px;
    height: 61px;
    right: -58px;
  }
}


/* V63.4 — Encabezado limpio, sin fondo abstracto */
.encabezado {
  isolation: auto;
  background: #ffffff !important;
}

.encabezado::before,
.encabezado::after {
  content: none !important;
  display: none !important;
}

/* Se conserva el logo centrado */
.enlace-logo-inicio {
  display: flex !important;
  width: fit-content;
  max-width: 100%;
  margin-right: auto !important;
  margin-left: auto !important;
}

.enlace-logo-inicio .logo {
  margin-right: auto !important;
  margin-left: auto !important;
}


/* V63.5 — Logo restaurado y centrado */
.enlace-logo-inicio {
  display: flex !important;
  width: fit-content;
  max-width: 100%;
  margin: 0 auto 4px !important;
  align-items: center;
  justify-content: center;
}

.enlace-logo-inicio .logo {
  display: block;
  width: min(320px, 80vw);
  max-height: 96px;
  margin: 0 auto !important;
  object-fit: contain;
}

.encabezado {
  background: #ffffff !important;
}

.encabezado::before,
.encabezado::after {
  content: none !important;
  display: none !important;
}

@media (max-width: 600px) {
  .enlace-logo-inicio .logo {
    width: min(275px, 78vw);
    max-height: 82px;
  }
}


/* V63.7 — Botones de navegación y precios compactos */

/* Secciones superiores: estado activo con color, sin subrayado */
.menu-ofertas button {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  min-height: 38px;
  padding: 8px 13px;
  border: 1px solid rgba(34, 86, 69, .13);
  border-radius: 12px;
  color: #53655d;
  background: rgba(255, 255, 255, .94);
  box-shadow: 0 3px 11px rgba(31, 67, 53, .055);
  font: inherit;
  font-size: 12px;
  font-weight: 400;
  white-space: nowrap;
  cursor: pointer;
  transition:
    color .18s ease,
    background .18s ease,
    border-color .18s ease,
    box-shadow .18s ease,
    transform .18s ease;
}

.menu-ofertas button::after,
.menu-ofertas button.activo::after {
  content: none !important;
  display: none !important;
}

.menu-ofertas button:hover,
.menu-ofertas button:focus-visible {
  color: #226650;
  border-color: rgba(31, 137, 99, .30);
  background: #f3faf6;
  box-shadow: 0 6px 15px rgba(31, 107, 80, .10);
  transform: translateY(-1px);
  outline: none;
}

.menu-ofertas button:active {
  transform: scale(.98);
}

.menu-ofertas button.activo {
  color: #ffffff;
  border-color: transparent;
  background:
    linear-gradient(135deg, #357866 0%, #55a280 100%);
  box-shadow: 0 7px 17px rgba(50, 125, 96, .22);
}

.menu-ofertas button.activo:hover,
.menu-ofertas button.activo:focus-visible {
  color: #ffffff;
  background:
    linear-gradient(135deg, #2e6e5d 0%, #4a9676 100%);
}

/* Tienda y Bancarios: mismo lenguaje visual que las secciones superiores */
.navegacion-inferior {
  gap: 7px;
  padding: 7px;
  border: 1px solid rgba(34, 86, 69, .13);
  background: rgba(255, 255, 255, .96);
}

.tab-inferior {
  min-height: 44px;
  gap: 7px;
  border: 1px solid rgba(34, 86, 69, .10);
  border-radius: 12px;
  color: #53655d;
  background: rgba(248, 251, 249, .88);
  font-size: 13px;
  font-weight: 400;
  box-shadow: 0 2px 8px rgba(31, 67, 53, .04);
  transition:
    color .18s ease,
    background .18s ease,
    border-color .18s ease,
    box-shadow .18s ease,
    transform .18s ease;
}

.tab-inferior strong {
  font-weight: 400;
}

.tab-inferior::after,
.tab-inferior.activo::after {
  content: none !important;
  display: none !important;
}

.tab-inferior:hover,
.tab-inferior:focus-visible {
  color: #226650;
  border-color: rgba(31, 137, 99, .27);
  background: #f1f8f4;
  box-shadow: 0 5px 13px rgba(31, 107, 80, .09);
  transform: translateY(-1px);
  outline: none;
}

.tab-inferior:active {
  transform: scale(.985);
}

.tab-inferior.activo {
  color: #ffffff;
  border-color: transparent;
  background:
    linear-gradient(135deg, #357866 0%, #55a280 100%);
  box-shadow: 0 7px 17px rgba(50, 125, 96, .22);
}

.tab-inferior.activo:hover,
.tab-inferior.activo:focus-visible {
  color: #ffffff;
  background:
    linear-gradient(135deg, #2e6e5d 0%, #4a9676 100%);
}

/* OFERTAS DEL DÍA: precios pequeños y siempre en línea horizontal */
.publicidad-precios {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-items: stretch;
  width: min(100%, 330px);
  gap: 5px;
  margin: 0 0 8px;
}

.precio-publicado-bloque,
.precio-cupon-bloque {
  min-width: 0;
  padding: 5px 7px;
  border-radius: 8px;
}

.precio-publicado-bloque span,
.precio-cupon-bloque span {
  margin-bottom: 1px;
  font-size: 7.5px;
  font-weight: 500;
  line-height: 1.1;
  letter-spacing: .18px;
}

.precio-publicado-bloque strong {
  display: block;
  font-size: 12px;
  line-height: 1.15;
}

.precio-cupon-bloque strong {
  display: block;
  font-size: 14px;
  line-height: 1.15;
}

@media (max-width: 600px) {
  .menu-ofertas button {
    min-height: 35px;
    padding: 7px 10px;
    font-size: 11px;
  }

  .tab-inferior {
    min-height: 42px;
    font-size: 12px;
  }

  .tab-inferior span {
    font-size: 17px;
  }

  .publicidad-precios {
    width: min(100%, 265px);
    gap: 4px;
    margin-bottom: 6px;
  }

  .precio-publicado-bloque,
  .precio-cupon-bloque {
    padding: 4px 6px;
    border-radius: 7px;
  }

  .precio-publicado-bloque span,
  .precio-cupon-bloque span {
    font-size: 6.8px;
  }

  .precio-publicado-bloque strong {
    font-size: 10.5px;
  }

  .precio-cupon-bloque strong {
    font-size: 12.5px;
  }
}


/* V63.8 — Ayuda plegable para cupones */
.ayuda-cupones {
  width: 100%;
  margin: 0 0 12px;
  overflow: hidden;
  border: 1px solid rgba(114, 137, 52, .17);
  border-radius: 13px;
  background: linear-gradient(135deg, rgba(255,253,239,.98), rgba(247,251,239,.98));
  box-shadow: 0 3px 12px rgba(76,91,41,.055);
}
.ayuda-cupones-toggle {
  display: flex;
  width: 100%;
  min-height: 43px;
  padding: 9px 13px;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  border: 0;
  color: #4f5e3f;
  background: transparent;
  font: inherit;
  font-size: 12.5px;
  font-weight: 400;
  cursor: pointer;
}
.ayuda-cupones-toggle:hover,
.ayuda-cupones-toggle:focus-visible {
  background: rgba(244,248,228,.72);
  outline: none;
}
.ayuda-cupones-toggle-texto {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.ayuda-cupones-icono { font-size: 16px; }
.ayuda-cupones-flecha { color: #809064; font-size: 10px; }
.ayuda-cupones-contenido {
  overflow: hidden;
  max-height: 0;
  transition: max-height .25s ease;
}
.ayuda-cupones-interior {
  padding: 2px 14px 14px;
  border-top: 1px solid rgba(114,137,52,.12);
}
.ayuda-cupones-interior h2 {
  margin: 12px 0 9px;
  color: #35462f;
  font-size: 13px;
  font-weight: 600;
}
.ayuda-cupones-pasos {
  display: grid;
  gap: 7px;
  margin: 0;
  padding: 0;
  list-style: none;
  counter-reset: pasos;
}
.ayuda-cupones-pasos li {
  position: relative;
  padding: 6px 8px 6px 36px;
  border-radius: 8px;
  color: #586456;
  background: rgba(255,255,255,.72);
  font-size: 10.5px;
  line-height: 1.35;
  counter-increment: pasos;
}
.ayuda-cupones-pasos li::before {
  content: counter(pasos);
  position: absolute;
  top: 5px;
  left: 7px;
  display: inline-flex;
  width: 21px;
  height: 21px;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  color: #fff;
  background: linear-gradient(135deg, #7da15f, #9bbd72);
  font-size: 9px;
  font-weight: 600;
}
.ayuda-cupones-entendido {
  display: block;
  min-width: 112px;
  min-height: 34px;
  margin: 11px 0 0 auto;
  padding: 7px 14px;
  border: 0;
  border-radius: 9px;
  color: #fff;
  background: linear-gradient(135deg, #668d57, #85a96b);
  font: inherit;
  font-size: 10.5px;
  cursor: pointer;
}
.ayuda-cupones-entendido:hover,
.ayuda-cupones-entendido:focus-visible {
  background: linear-gradient(135deg, #587e4c, #789c5f);
  outline: none;
}
@media (max-width: 600px) {
  .ayuda-cupones { margin-bottom: 9px; border-radius: 11px; }
  .ayuda-cupones-toggle { min-height: 40px; padding: 8px 11px; font-size: 11.5px; }
  .ayuda-cupones-interior { padding: 2px 10px 11px; }
  .ayuda-cupones-interior h2 { font-size: 12px; }
  .ayuda-cupones-pasos { gap: 5px; }
  .ayuda-cupones-pasos li { padding: 5px 7px 5px 33px; font-size: 9.5px; }
  .ayuda-cupones-pasos li::before { top: 4px; left: 6px; width: 20px; height: 20px; }
  .ayuda-cupones-entendido { min-height: 32px; font-size: 10px; }
}


/* V63.8.2 — Tip dentro de la ayuda de cupones */
.ayuda-cupones-tip {
  margin: 9px 0 0;
  padding: 8px 10px;
  border-left: 3px solid rgba(102, 141, 87, .55);
  border-radius: 7px;
  color: #566253;
  background: rgba(255, 255, 255, .72);
  font-size: 10px;
  line-height: 1.4;
}

.ayuda-cupones-tip strong {
  color: #40533b;
}

@media (max-width: 600px) {
  .ayuda-cupones-tip {
    padding: 7px 9px;
    font-size: 9.2px;
  }
}


/* V63.10 — Flechas externas sin desplazar el menú */
.menu-ofertas-contenedor {
  width: min(930px, calc(100% - 68px));
  margin-right: auto;
  margin-left: auto;
  padding-right: 0 !important;
  padding-left: 0 !important;
}

.menu-ofertas {
  width: 100% !important;
  margin: 0 !important;
  padding-right: 5px !important;
  padding-left: 5px !important;
}

/* Las flechas permanecen a los lados, no arriba ni abajo */
.menu-ofertas-flecha-anterior {
  left: -34px !important;
}

.menu-ofertas-flecha-siguiente {
  right: -34px !important;
}

/* El degradado comienza en el borde real del menú */
.menu-ofertas-contenedor::before {
  left: 0 !important;
}

.menu-ofertas-contenedor::after {
  right: 0 !important;
}

@media (max-width: 600px) {
  .menu-ofertas-contenedor {
    width: calc(100% - 62px);
    padding-right: 0 !important;
    padding-left: 0 !important;
  }

  .menu-ofertas-flecha-anterior {
    left: -30px !important;
  }

  .menu-ofertas-flecha-siguiente {
    right: -30px !important;
  }
}

@media (max-width: 360px) {
  .menu-ofertas-contenedor {
    width: calc(100% - 56px);
  }

  .menu-ofertas-flecha {
    width: 25px;
  }

  .menu-ofertas-flecha-anterior {
    left: -27px !important;
  }

  .menu-ofertas-flecha-siguiente {
    right: -27px !important;
  }
}


/* V63.10.1 - Compactar "¿Cómo usar los cupones?" */
.ayuda-cupones{
  margin:0 0 6px !important;
}

.ayuda-cupones-toggle{
  min-height:36px !important;
  padding:6px 12px !important;
}

.ayuda-cupones-interior{
  padding:0 12px 10px !important;
}

.ayuda-cupones-pasos{
  gap:4px !important;
}

.ayuda-cupones-pasos li{
  min-height:auto !important;
  padding:5px 8px 5px 34px !important;
}

.ayuda-cupones-tip{
  margin-top:6px !important;
  padding:6px 9px !important;
}

.ayuda-cupones-entendido{
  margin-top:8px !important;
}

@media (max-width:600px){
  .ayuda-cupones{
    margin-bottom:5px !important;
  }

  .ayuda-cupones-toggle{
    min-height:34px !important;
    padding:5px 10px !important;
  }

  .ayuda-cupones-interior{
    padding:0 10px 8px !important;
  }
}
